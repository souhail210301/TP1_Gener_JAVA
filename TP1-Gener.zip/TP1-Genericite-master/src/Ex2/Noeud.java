package Ex2;

class Noeud {
Object info;
Noeud suivant;
}
