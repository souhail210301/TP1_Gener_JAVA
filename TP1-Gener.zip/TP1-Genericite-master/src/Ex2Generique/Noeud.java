package Ex2Generique;

class Noeud <T>{
T info;
Noeud<T> suivant;
}
