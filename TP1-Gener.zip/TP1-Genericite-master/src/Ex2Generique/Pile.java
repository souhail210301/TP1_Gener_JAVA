package Ex2Generique;

interface Pile <T> {
public boolean estVide();
public  Object dernier();
public void depiler();
public void empiler(Object o);
}
